document.addEventListener('DOMContentLoaded', () => {
  let currentLang = localStorage.getItem('lang') || 'en';
  setLanguage(currentLang);
  generateMeatLists();
  attachMeatItemListeners();
  attachLanguageButtons();
  attachDarkModeToggle();
  attachOrderButton();
  attachWhatsAppToggle();
  makeOrderSummaryMovable();
  
  if (localStorage.getItem('mode') === 'dark') {
    document.documentElement.classList.add('dark');
    document.getElementById('mode-toggle').textContent = translations[currentLang].toggle_mode.replace('Dark', 'Light');
  }
});

function setLanguage(lang) {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    el.textContent = translations[lang][key];
  });
  updateMeatNames(lang);
  currentLang = lang;
  localStorage.setItem('lang', lang);
}

function updateMeatNames(lang) {
  document.querySelectorAll('.meat-item').forEach(item => {
    const category = item.getAttribute('data-category');
    const id = item.getAttribute('data-id');
    const meat = meats[category].find(m => m.id === id);
    item.querySelector('.name').textContent = meat.name[lang];
  });
}

function generateMeatLists() {
  Object.keys(meats).forEach(category => {
    const list = document.querySelector(`.grid[data-category="${category}"]`);
    meats[category].forEach(meat => {
      const item = document.createElement('div');
      item.classList.add('meat-item', 'bg-white', 'dark:bg-gray-700', 'p-4', 'rounded-lg', 'shadow-md');
      item.setAttribute('data-category', category);
      item.setAttribute('data-id', meat.id);
      item.innerHTML = `
        <span class="name text-lg font-medium text-red-700">${meat.name[currentLang]}</span>
        <span class="price text-gray-500 dark:text-gray-300">${meat.price} RWF</span>
        <div class="flex items-center mt-2">
          <button class="minus bg-red-600 text-white px-2 py-1 rounded">-</button>
          <input type="number" value="0" min="0" step="0.5" class="w-16 text-center mx-2 border rounded"> kg
          <button class="plus bg-red-600 text-white px-2 py-1 rounded">+</button>
        </div>
      `;
      list.appendChild(item);
    });
  });
}

function attachMeatItemListeners() {
  document.querySelectorAll('.meat-item').forEach(item => {
    const minus = item.querySelector('.minus');
    const plus = item.querySelector('.plus');
    const input = item.querySelector('input');
    minus.addEventListener('click', () => {
      if (input.value > 0) input.value = parseFloat(input.value) - 0.5;
      updateOrderSummary();
    });
    plus.addEventListener('click', () => {
      input.value = parseFloat(input.value) + 0.5;
      updateOrderSummary();
    });
    input.addEventListener('change', updateOrderSummary);
  });
}

function attachLanguageButtons() {
  document.querySelectorAll('[data-lang]').forEach(btn => {
    btn.addEventListener('click', () => {
      const lang = btn.getAttribute('data-lang');
      setLanguage(lang);
    });
  });
}

function attachDarkModeToggle() {
  document.getElementById('mode-toggle').addEventListener('click', () => {
    document.documentElement.classList.toggle('dark');
    const isDark = document.documentElement.classList.contains('dark');
    localStorage.setItem('mode', isDark ? 'dark' : 'light');
    document.getElementById('mode-toggle').textContent = isDark ? translations[currentLang].toggle_mode.replace('Dark', 'Light') : translations[currentLang].toggle_mode;
  });
}

function attachOrderButton() {
  document.getElementById('order-btn').addEventListener('click', () => {
    const name = document.getElementById('name').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const address = document.getElementById('address').value.trim();
    const deliveryTime = document.getElementById('delivery-time').value.trim();
    const deliveryFee = parseFloat(document.getElementById('delivery-fee').value) || 0;

    if (!name || !phone || !address || !deliveryTime) {
      alert('Please fill in all delivery details before placing an order.');
      return;
    }

    const selectedItems = [];
    let subtotal = 0;
    document.querySelectorAll('.meat-item').forEach(item => {
      const quantity = parseFloat(item.querySelector('input').value) || 0;
      if (quantity > 0) {
        const category = item.getAttribute('data-category');
        const id = item.getAttribute('data-id');
        const meat = meats[category].find(m => m.id === id);
        const totalPrice = meat.price * quantity;
        selectedItems.push(`${quantity}kg ${meat.name[currentLang]} - ${totalPrice} RWF`);
        subtotal += totalPrice;
      }
    });
  
    if (selectedItems.length === 0) {
      alert('Please select at least one item to order.');
      return;
    }
  
    const total = subtotal + deliveryFee;

    const message = `
Hello Chez Eric Butchery,
I am ${name}, my phone number is ${phone}.
I would like to order:
${selectedItems.join('\n')}
Delivery to: ${address}
Preferred time: ${deliveryTime}
Subtotal: ${subtotal} RWF
Delivery Fee: ${deliveryFee} RWF
Total: ${total} RWF
Please confirm the total and delivery details.

    `.trim();
  
    const whatsappUrl = `https://wa.me/+250791846153?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  });
}

function updateOrderSummary() {
  const selectedItems = [];
  let subtotal = 0;
  document.querySelectorAll('.meat-item').forEach(item => {
    const quantity = parseFloat(item.querySelector('input').value) || 0;
    if (quantity > 0) {
      const category = item.getAttribute('data-category');
      const id = item.getAttribute('data-id');
      const meat = meats[category].find(m => m.id === id);
      const totalPrice = meat.price * quantity;
      selectedItems.push({ name: meat.name[currentLang], quantity, totalPrice });
      subtotal += totalPrice;
    }
  });
  document.querySelector('.selected-items').innerHTML = selectedItems
    .map(item => `<p>${item.quantity}kg ${item.name} - ${item.totalPrice} RWF</p>`)
    .join('');
  document.querySelector('.subtotal').textContent = `Subtotal: ${subtotal} RWF`;
  const deliveryFee = parseFloat(document.getElementById('delivery-fee').value) || 0;
  const total = subtotal + deliveryFee;
  document.querySelector('.total').textContent = `Total: ${total} RWF`;
}

function attachWhatsAppToggle() {
  const whatsappToggle = document.getElementById('whatsapp-toggle');
  whatsappToggle.addEventListener('click', () => {
    whatsappToggle.classList.toggle('hidden');
  });
}

function makeOrderSummaryMovable() {
  const orderSummary = document.getElementById('order-summary');
  let isDragging = false;
  let startX, startY, initialLeft, initialTop;

  orderSummary.addEventListener('mousedown', (e) => {
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
    initialLeft = orderSummary.offsetLeft;
    initialTop = orderSummary.offsetTop;
    orderSummary.style.position = 'absolute';
    orderSummary.style.zIndex = 1000;
  });

  document.addEventListener('mousemove', (e) => {
    if (isDragging) {
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      orderSummary.style.left = `${initialLeft + dx}px`;
      orderSummary.style.top = `${initialTop + dy}px`;
    }
  });

  document.addEventListener('mouseup', () => {
    isDragging = false;
  });
}