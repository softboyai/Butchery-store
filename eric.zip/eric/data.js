window.meats = {
  beef: [
    { id: 'm1', name: { en: 'Mixed Meat', rw: 'Imvange' }, price: 6000 },
    { id: 'm2', name: { en: 'Fresh Beef', rw: 'Iroti' }, price: 8000 },
    { id: 'm3', name: { en: 'Beef Back Meat (Coteret)', rw: 'Coteret' }, price: 6000 },
    { id: 'm4', name: { en: 'Ribs (Imbavu)', rw: 'Imbavu' }, price: 5800 },
    { id: 'm5', name: { en: 'Beef Leg Meat (Ijari)', rw: 'Ijari' }, price: 6000 }
  ],
  fish: [
    { id: 'f1', name: { en: 'Large Tilapia (Trapia Nini)', rw: 'Ifi ya Tilapia nini' }, price: 6000 },
    { id: 'f2', name: { en: 'Small Tilapia (Trapia Ntoya)', rw: 'Ifi ya Tilapia ntoya' }, price: 4500 },
    { id: 'f3', name: { en: 'Captain Fish Fillet', rw: 'Ifi ya Kapiteni' }, price: 12500 },
    { id: 'f4', name: { en: 'Tilapia Fish Fillet', rw: 'Ifi ya Tilapia yuzuye' }, price: 12500 },
    { id: 'f5', name: { en: 'Pangasius Fish Fillet', rw: 'Ifi ya Pangasius' }, price: 8000 }
  ],
  chicken: [
    { id: 'c1', name: { en: 'Foreign Chicken (Inzungu)', rw: "Inkoko y'inzungu" }, price: 5000 },
    { id: 'c2', name: { en: 'Traditional Chicken (Inyarwanda)', rw: "Inkoko y'inyarwanda" }, price: 6000 }
  ],
  viandache: [
    { id: 'v1', name: { en: 'Viandache (Beef Dish)', rw: 'Viandache' }, price: 6000 }
  ]
};